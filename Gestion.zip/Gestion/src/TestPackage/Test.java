/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestPackage;

import Entities.Categorie;
import Services.ServiceCategorie;
import Services.ServiceProduit;

/**
 *
 * @author Asus
 */
public class Test {
      public static void main(String[] args){
            ServiceCategorie serviceCategorie = new ServiceCategorie();
            ServiceProduit serviceProduit = new ServiceProduit();
            //Categorie c = new Categorie(10,"gofmflaa");
            //serviceCategorie.AddCategorie(c);
    }
    
}
